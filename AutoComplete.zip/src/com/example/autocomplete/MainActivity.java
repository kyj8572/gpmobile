package com.example.autocomplete;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends Activity implements TextWatcher  {
	 
	WordDBHelper mHelper;
	SQLiteDatabase db;
	private AutoCompleteTextView auto;
	private SimpleCursorAdapter simple;
	private ArrayList<String> list2;
	String autoword, fir;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);

			mHelper = new WordDBHelper(this);
			db = mHelper.getReadableDatabase();
			auto = (AutoCompleteTextView) findViewById(R.id.autoedit);
			auto.addTextChangedListener(this);
			list2 = new ArrayList<String>();
	}


	public void onTextChanged(CharSequence text, int start, int before, int after) { //������ ������ ������ ����

			autoword = auto.getText().toString()+""; //�Էµ� �� �������
			if (autoword == "") {  //�Էµ� ù���ڰ� ������ fir�� �ֱ�
				fir = "word";   //������ ��� text�� backspace �ϸ� �����߻�
			}else{
				fir = autoword.substring(0,1);  // 'word'�� DB�� �÷���
			}
			Cursor cursor = null;
			try {
				String sql = "select word from word where word like '%'";
				cursor = db.rawQuery(sql, null);
				
				while(cursor.moveToNext()){
					String word =cursor.getString(cursor.getColumnIndex("word"));
					list2.add(word.toString()); //arraylist�� �ٽ� �迭
				}

				cursor.close();
				db.close();
			} catch (Exception e) {
				Log.e("ErrorMessage2 : ", e.getMessage());
			}


			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, list2);   // adapter�� �ڵ��ϼ� ����
			auto.setAdapter(adapter);
	}


	@Override
	public void afterTextChanged(Editable arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
			int arg3) {
		// TODO Auto-generated method stub
		
	}
}
 
